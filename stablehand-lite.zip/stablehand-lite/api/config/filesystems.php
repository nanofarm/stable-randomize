<?php
return [
    'default' => 'local',
    'disks' => [
        'local' => [
            'driver' => 'local',
            'root' => storage_path('app'),
        ],
        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => env('APP_URL', 'http://localhost') . '/storage',
            'visibility' => 'public',
        ],
    ],
    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],
];
